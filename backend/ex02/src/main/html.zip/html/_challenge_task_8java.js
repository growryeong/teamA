var _challenge_task_8java =
[
    [ "org.zerock.domain.ChallengeTask", "classorg_1_1zerock_1_1domain_1_1_challenge_task.html", "classorg_1_1zerock_1_1domain_1_1_challenge_task" ]
];