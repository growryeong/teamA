var _challenge_8java =
[
    [ "org.zerock.domain.Challenge", "classorg_1_1zerock_1_1domain_1_1_challenge.html", "classorg_1_1zerock_1_1domain_1_1_challenge" ]
];