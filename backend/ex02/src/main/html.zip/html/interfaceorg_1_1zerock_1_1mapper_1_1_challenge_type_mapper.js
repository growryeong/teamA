var interfaceorg_1_1zerock_1_1mapper_1_1_challenge_type_mapper =
[
    [ "findByName", "interfaceorg_1_1zerock_1_1mapper_1_1_challenge_type_mapper.html#a1a9c9c585050921096760a19b007d573", null ]
];