var classorg_1_1zerock_1_1domain_1_1_community_post =
[
    [ "setCurrentTimestamp", "classorg_1_1zerock_1_1domain_1_1_community_post.html#a4623b829f67aa8ae9a20953e9f0e6db4", null ],
    [ "content", "classorg_1_1zerock_1_1domain_1_1_community_post.html#ae5ce0100152d79e757ad72819c0f8288", null ],
    [ "postId", "classorg_1_1zerock_1_1domain_1_1_community_post.html#a7b10890ef4c67e0953edf7d51b3ff80a", null ],
    [ "timestamp", "classorg_1_1zerock_1_1domain_1_1_community_post.html#a77aede395d7b68597986deca41acf7e6", null ],
    [ "title", "classorg_1_1zerock_1_1domain_1_1_community_post.html#ae1f20b94c1fbc8d613785ac57158842a", null ],
    [ "userChallengeId", "classorg_1_1zerock_1_1domain_1_1_community_post.html#a6b133817b8514c2f2bbc21725125a163", null ],
    [ "userId", "classorg_1_1zerock_1_1domain_1_1_community_post.html#ad7d13976b3826c4a00f53318d4884ed4", null ],
    [ "viewCount", "classorg_1_1zerock_1_1domain_1_1_community_post.html#aebac2b05b4a59964070bcce7e2c72d3c", null ]
];