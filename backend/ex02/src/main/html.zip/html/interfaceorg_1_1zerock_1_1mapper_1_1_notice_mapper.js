var interfaceorg_1_1zerock_1_1mapper_1_1_notice_mapper =
[
    [ "getNotice", "interfaceorg_1_1zerock_1_1mapper_1_1_notice_mapper.html#ad15f75322a103b484fe04d9888c1ed94", null ],
    [ "getNoticeList", "interfaceorg_1_1zerock_1_1mapper_1_1_notice_mapper.html#a6506cc290986ff3ac093bfb3c18e6191", null ],
    [ "insertNotice", "interfaceorg_1_1zerock_1_1mapper_1_1_notice_mapper.html#acb9a0a84919be92cba94a7d75c1786d6", null ]
];