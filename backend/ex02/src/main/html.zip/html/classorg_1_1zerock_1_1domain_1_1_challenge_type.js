var classorg_1_1zerock_1_1domain_1_1_challenge_type =
[
    [ "activityTypeId", "classorg_1_1zerock_1_1domain_1_1_challenge_type.html#a34abaa3a99bc66fe2f5bc78c75b73eb3", null ],
    [ "icon", "classorg_1_1zerock_1_1domain_1_1_challenge_type.html#a1e0ba8bf2ee251b9887024bf8d192380", null ],
    [ "name", "classorg_1_1zerock_1_1domain_1_1_challenge_type.html#a0697bf1512431ff70d3ffff9fa057f97", null ]
];