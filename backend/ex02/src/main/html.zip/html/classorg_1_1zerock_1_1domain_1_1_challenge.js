var classorg_1_1zerock_1_1domain_1_1_challenge =
[
    [ "activityTypeId", "classorg_1_1zerock_1_1domain_1_1_challenge.html#a7ea267f355a0fc7d2385eecce7fb6048", null ],
    [ "challengeId", "classorg_1_1zerock_1_1domain_1_1_challenge.html#a21b0d1372698d18752cafac6159804ad", null ],
    [ "description", "classorg_1_1zerock_1_1domain_1_1_challenge.html#a32a5d6731c1bf59d38082f6c1a80bee0", null ],
    [ "duration", "classorg_1_1zerock_1_1domain_1_1_challenge.html#ae498315d70044bf6e112dc7cb400069e", null ],
    [ "title", "classorg_1_1zerock_1_1domain_1_1_challenge.html#a6ef94fa958dd77ff51c652a93b826115", null ]
];