var _criteria_8java =
[
    [ "org.zerock.domain.Criteria", "classorg_1_1zerock_1_1domain_1_1_criteria.html", "classorg_1_1zerock_1_1domain_1_1_criteria" ]
];