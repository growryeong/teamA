var interfaceorg_1_1zerock_1_1mapper_1_1_user_challenge_mapper =
[
    [ "findByUser", "interfaceorg_1_1zerock_1_1mapper_1_1_user_challenge_mapper.html#aeea43e6b52f52fcef5f7f34d131b5d18", null ],
    [ "findByUserAndChallenge", "interfaceorg_1_1zerock_1_1mapper_1_1_user_challenge_mapper.html#ae736826d1a44267d6096d8fea7fd669f", null ],
    [ "findOngoingChallenge", "interfaceorg_1_1zerock_1_1mapper_1_1_user_challenge_mapper.html#ae8358921b9084f490d4c0dc93d6840e7", null ],
    [ "findOngoingChallengeByUserId", "interfaceorg_1_1zerock_1_1mapper_1_1_user_challenge_mapper.html#a6c4659d3bb763604b94eb1adf4680414", null ],
    [ "getUserChallengeDetails", "interfaceorg_1_1zerock_1_1mapper_1_1_user_challenge_mapper.html#a0a59516a89020931684005d0e7ca1927", null ],
    [ "insertUserChallenge", "interfaceorg_1_1zerock_1_1mapper_1_1_user_challenge_mapper.html#a647a96376df7b31c09e45141faae2d3f", null ]
];