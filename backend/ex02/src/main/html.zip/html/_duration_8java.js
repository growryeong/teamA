var _duration_8java =
[
    [ "org.zerock.domain.Duration", "classorg_1_1zerock_1_1domain_1_1_duration.html", "classorg_1_1zerock_1_1domain_1_1_duration" ]
];