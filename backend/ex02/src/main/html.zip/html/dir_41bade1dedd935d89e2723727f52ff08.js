var dir_41bade1dedd935d89e2723727f52ff08 =
[
    [ "BoardVO.java", "_board_v_o_8java.html", "_board_v_o_8java" ],
    [ "Challenge.java", "_challenge_8java.html", "_challenge_8java" ],
    [ "ChallengeTask.java", "_challenge_task_8java.html", "_challenge_task_8java" ],
    [ "ChallengeType.java", "_challenge_type_8java.html", "_challenge_type_8java" ],
    [ "Comment.java", "_comment_8java.html", "_comment_8java" ],
    [ "CommunityPost.java", "_community_post_8java.html", "_community_post_8java" ],
    [ "CommunityPostDTO.java", "_community_post_d_t_o_8java.html", "_community_post_d_t_o_8java" ],
    [ "Criteria.java", "_criteria_8java.html", "_criteria_8java" ],
    [ "Duration.java", "_duration_8java.html", "_duration_8java" ],
    [ "EmailChangeDTO.java", "_email_change_d_t_o_8java.html", "_email_change_d_t_o_8java" ],
    [ "LoginDTO.java", "_login_d_t_o_8java.html", "_login_d_t_o_8java" ],
    [ "NoticeDTO.java", "_notice_d_t_o_8java.html", "_notice_d_t_o_8java" ],
    [ "PasswordChangeDTO.java", "_password_change_d_t_o_8java.html", "_password_change_d_t_o_8java" ],
    [ "User.java", "_user_8java.html", "_user_8java" ],
    [ "UserChallenge.java", "_user_challenge_8java.html", "_user_challenge_8java" ],
    [ "UserChallengeDTO.java", "_user_challenge_d_t_o_8java.html", "_user_challenge_d_t_o_8java" ],
    [ "UserDTO.java", "_user_d_t_o_8java.html", "_user_d_t_o_8java" ]
];