var _comment_mapper_8java =
[
    [ "org.zerock.mapper.CommentMapper", "interfaceorg_1_1zerock_1_1mapper_1_1_comment_mapper.html", "interfaceorg_1_1zerock_1_1mapper_1_1_comment_mapper" ]
];