var _user_service_8java =
[
    [ "org.zerock.service.UserService", "interfaceorg_1_1zerock_1_1service_1_1_user_service.html", "interfaceorg_1_1zerock_1_1service_1_1_user_service" ]
];