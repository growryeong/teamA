var classorg_1_1zerock_1_1domain_1_1_comment =
[
    [ "commentId", "classorg_1_1zerock_1_1domain_1_1_comment.html#a88c2f47d5d35b68b4e6aaf6b34614c9e", null ],
    [ "commentText", "classorg_1_1zerock_1_1domain_1_1_comment.html#a8cfd282da0b1f45d806c4fa78819f079", null ],
    [ "postId", "classorg_1_1zerock_1_1domain_1_1_comment.html#accf8ffaf2671703f26be6772cbf8b786", null ],
    [ "timestamp", "classorg_1_1zerock_1_1domain_1_1_comment.html#aa5cdb29ae03b6af0390b1d09e9741d94", null ],
    [ "userId", "classorg_1_1zerock_1_1domain_1_1_comment.html#a565fb43f3ce15f5e6f9c445eb15d6178", null ]
];