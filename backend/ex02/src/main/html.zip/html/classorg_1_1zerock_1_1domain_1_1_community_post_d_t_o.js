var classorg_1_1zerock_1_1domain_1_1_community_post_d_t_o =
[
    [ "challengeId", "classorg_1_1zerock_1_1domain_1_1_community_post_d_t_o.html#a72285c1c3ee97342c790754da47bcae5", null ],
    [ "content", "classorg_1_1zerock_1_1domain_1_1_community_post_d_t_o.html#a54b9cd25aba34f407d872adc7b18b7ac", null ],
    [ "postId", "classorg_1_1zerock_1_1domain_1_1_community_post_d_t_o.html#a0a2e70a3bf63b9a3244ab94b158495a4", null ],
    [ "timestamp", "classorg_1_1zerock_1_1domain_1_1_community_post_d_t_o.html#a274e476bbc9f66512753eb556f45ea01", null ],
    [ "title", "classorg_1_1zerock_1_1domain_1_1_community_post_d_t_o.html#a7205465c676728e7ef9df115672dc90d", null ],
    [ "userChallengeId", "classorg_1_1zerock_1_1domain_1_1_community_post_d_t_o.html#a60fe56fc7019cf7c08ec7c50c1f13700", null ],
    [ "userId", "classorg_1_1zerock_1_1domain_1_1_community_post_d_t_o.html#a260bd2ffe611ab0cde062ec6d010e9ca", null ],
    [ "viewCount", "classorg_1_1zerock_1_1domain_1_1_community_post_d_t_o.html#a5359f07dac50b8dfa6d5089364889dd2", null ]
];