var _user_challenge_d_t_o_8java =
[
    [ "org.zerock.domain.UserChallengeDTO", "classorg_1_1zerock_1_1domain_1_1_user_challenge_d_t_o.html", "classorg_1_1zerock_1_1domain_1_1_user_challenge_d_t_o" ]
];