var searchData=
[
  ['saveuserchallenge_0',['saveUserChallenge',['../classorg_1_1zerock_1_1controller_1_1_user_challenge_controller.html#a92873b0e26b4b4c63c9503febfebd1ad',1,'org.zerock.controller.UserChallengeController.saveUserChallenge()'],['../classorg_1_1zerock_1_1service_1_1_user_challenge_service.html#abbbd50521c8facd21bd83c2919329517',1,'org.zerock.service.UserChallengeService.saveUserChallenge()']]],
  ['setcurrenttimestamp_1',['setCurrentTimestamp',['../classorg_1_1zerock_1_1domain_1_1_community_post.html#a4623b829f67aa8ae9a20953e9f0e6db4',1,'org::zerock::domain::CommunityPost']]]
];
