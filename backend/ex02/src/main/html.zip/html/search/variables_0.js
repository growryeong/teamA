var searchData=
[
  ['activitytypeid_0',['activityTypeId',['../classorg_1_1zerock_1_1domain_1_1_challenge.html#a7ea267f355a0fc7d2385eecce7fb6048',1,'org.zerock.domain.Challenge.activityTypeId'],['../classorg_1_1zerock_1_1domain_1_1_challenge_type.html#a34abaa3a99bc66fe2f5bc78c75b73eb3',1,'org.zerock.domain.ChallengeType.activityTypeId']]],
  ['amount_1',['amount',['../classorg_1_1zerock_1_1domain_1_1_criteria.html#ac5f15e3845bb7e3cfb5c4ba40dbf4126',1,'org::zerock::domain::Criteria']]],
  ['author_2',['author',['../classorg_1_1zerock_1_1domain_1_1_notice_d_t_o.html#a3bec41a4b9eae56b24d9f65386be5d16',1,'org::zerock::domain::NoticeDTO']]],
  ['authorid_3',['authorId',['../classorg_1_1zerock_1_1domain_1_1_notice_d_t_o.html#aecd628ed7ef0d80747f9f3435678556b',1,'org::zerock::domain::NoticeDTO']]]
];
