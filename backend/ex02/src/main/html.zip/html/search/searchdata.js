var indexSectionsWithContent =
{
  0: "abcdefghijklnoprstuvw",
  1: "abcdehlnpuw",
  2: "o",
  3: "abcdehlnpuw",
  4: "acdfghijlorstu",
  5: "abcdeiklnprstuvw"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables"
};

var indexSectionLabels =
{
  0: "모두",
  1: "클래스",
  2: "네임스페이스들",
  3: "파일들",
  4: "함수",
  5: "변수"
};

