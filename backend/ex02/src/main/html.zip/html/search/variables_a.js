var searchData=
[
  ['regdate_0',['regdate',['../classorg_1_1zerock_1_1domain_1_1_board_v_o.html#a21ea51ce3639ef93fdcc03c6e8a7cfc2',1,'org::zerock::domain::BoardVO']]]
];
