var searchData=
[
  ['startdate_0',['startDate',['../classorg_1_1zerock_1_1domain_1_1_user_challenge.html#a4225172f85d55b7242c1a5fb3e25c612',1,'org.zerock.domain.UserChallenge.startDate'],['../classorg_1_1zerock_1_1domain_1_1_user_challenge_d_t_o.html#a57067a9a56190b769c6faf5bee3c37c1',1,'org.zerock.domain.UserChallengeDTO.startDate']]],
  ['status_1',['status',['../classorg_1_1zerock_1_1domain_1_1_user_challenge.html#a5759692e6938d59ac658d82a56fcc4c5',1,'org.zerock.domain.UserChallenge.status'],['../classorg_1_1zerock_1_1domain_1_1_user_challenge_d_t_o.html#ac9505e0cd47d43e43694a64591487c8e',1,'org.zerock.domain.UserChallengeDTO.status']]]
];
