var searchData=
[
  ['addcomment_0',['addComment',['../classorg_1_1zerock_1_1controller_1_1_comment_controller.html#ac224e24d59843057406207438377b3f9',1,'org.zerock.controller.CommentController.addComment()'],['../classorg_1_1zerock_1_1service_1_1_comment_service.html#a1e49a7e511c54b882ea4ce429f7d5df8',1,'org.zerock.service.CommentService.addComment()']]],
  ['addcorsmappings_1',['addCorsMappings',['../classorg_1_1zerock_1_1config_1_1_web_config.html#a70c4dc823b265a0f3a6106361e408ea6',1,'org::zerock::config::WebConfig']]]
];
