var searchData=
[
  ['icon_0',['icon',['../classorg_1_1zerock_1_1domain_1_1_challenge_type.html#a1e0ba8bf2ee251b9887024bf8d192380',1,'org::zerock::domain::ChallengeType']]],
  ['id_1',['id',['../classorg_1_1zerock_1_1domain_1_1_notice_d_t_o.html#aa8f5ee867d4720ae5bc00de06b255be8',1,'org::zerock::domain::NoticeDTO']]],
  ['isadmin_2',['isAdmin',['../classorg_1_1zerock_1_1domain_1_1_user.html#ab7fd098bdebbf339305f20c2add8e556',1,'org::zerock::domain::User']]]
];
