var _community_mapper_8java =
[
    [ "org.zerock.mapper.CommunityMapper", "interfaceorg_1_1zerock_1_1mapper_1_1_community_mapper.html", "interfaceorg_1_1zerock_1_1mapper_1_1_community_mapper" ]
];