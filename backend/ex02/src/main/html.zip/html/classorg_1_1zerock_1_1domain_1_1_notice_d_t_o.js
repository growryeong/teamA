var classorg_1_1zerock_1_1domain_1_1_notice_d_t_o =
[
    [ "toString", "classorg_1_1zerock_1_1domain_1_1_notice_d_t_o.html#a65305c59e19e5b6c72560053a8615174", null ],
    [ "author", "classorg_1_1zerock_1_1domain_1_1_notice_d_t_o.html#a3bec41a4b9eae56b24d9f65386be5d16", null ],
    [ "authorId", "classorg_1_1zerock_1_1domain_1_1_notice_d_t_o.html#aecd628ed7ef0d80747f9f3435678556b", null ],
    [ "content", "classorg_1_1zerock_1_1domain_1_1_notice_d_t_o.html#a23b8435575fea01eabb1a6e0cd37d794", null ],
    [ "id", "classorg_1_1zerock_1_1domain_1_1_notice_d_t_o.html#aa8f5ee867d4720ae5bc00de06b255be8", null ],
    [ "timestamp", "classorg_1_1zerock_1_1domain_1_1_notice_d_t_o.html#afa10cc66a64d7d69d5f3700997c46ddf", null ],
    [ "title", "classorg_1_1zerock_1_1domain_1_1_notice_d_t_o.html#aa0a8b1b909cc67d9d8aa2f10ab4691d8", null ]
];