var _notice_service_8java =
[
    [ "org.zerock.service.NoticeService", "classorg_1_1zerock_1_1service_1_1_notice_service.html", "classorg_1_1zerock_1_1service_1_1_notice_service" ]
];