var classorg_1_1zerock_1_1domain_1_1_criteria =
[
    [ "Criteria", "classorg_1_1zerock_1_1domain_1_1_criteria.html#a38811b499095e9be643a4045d07ef277", null ],
    [ "Criteria", "classorg_1_1zerock_1_1domain_1_1_criteria.html#afbbfe421498e6d333df5941389e97822", null ],
    [ "getTypeArr", "classorg_1_1zerock_1_1domain_1_1_criteria.html#a9cbac5a2deec88671f8c30f295b43215", null ],
    [ "amount", "classorg_1_1zerock_1_1domain_1_1_criteria.html#ac5f15e3845bb7e3cfb5c4ba40dbf4126", null ],
    [ "keyword", "classorg_1_1zerock_1_1domain_1_1_criteria.html#a9e16373ab433f73262a395f28ffebf1a", null ],
    [ "pageNum", "classorg_1_1zerock_1_1domain_1_1_criteria.html#ab72709582f73231284cf03fae8288a30", null ],
    [ "type", "classorg_1_1zerock_1_1domain_1_1_criteria.html#aa83b73c4a6dd5023f934339a1edae081", null ]
];