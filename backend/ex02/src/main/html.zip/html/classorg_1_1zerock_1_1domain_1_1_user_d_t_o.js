var classorg_1_1zerock_1_1domain_1_1_user_d_t_o =
[
    [ "email", "classorg_1_1zerock_1_1domain_1_1_user_d_t_o.html#aed38a0d243b162af96ea272f68966d0b", null ],
    [ "password", "classorg_1_1zerock_1_1domain_1_1_user_d_t_o.html#aa2c5cfd3b6a1835a1de7679b11660882", null ],
    [ "userId", "classorg_1_1zerock_1_1domain_1_1_user_d_t_o.html#a0176d9d41d7d9a6fc4e1234927e375c0", null ],
    [ "username", "classorg_1_1zerock_1_1domain_1_1_user_d_t_o.html#a0f8449a7b184d997ffb336a703faf5f2", null ]
];