var _user_challenge_service_8java =
[
    [ "org.zerock.service.UserChallengeService", "classorg_1_1zerock_1_1service_1_1_user_challenge_service.html", "classorg_1_1zerock_1_1service_1_1_user_challenge_service" ]
];