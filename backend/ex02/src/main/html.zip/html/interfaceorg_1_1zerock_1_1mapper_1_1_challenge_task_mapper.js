var interfaceorg_1_1zerock_1_1mapper_1_1_challenge_task_mapper =
[
    [ "findAllTasks", "interfaceorg_1_1zerock_1_1mapper_1_1_challenge_task_mapper.html#a1bd3a08eafa94e64512064345b1b4d81", null ],
    [ "findByChallengeId", "interfaceorg_1_1zerock_1_1mapper_1_1_challenge_task_mapper.html#a5ea98e8da08bc6100ae9079b4698f30c", null ],
    [ "insert", "interfaceorg_1_1zerock_1_1mapper_1_1_challenge_task_mapper.html#a45b9cbec8de3a973a1fac9a3234a9689", null ]
];