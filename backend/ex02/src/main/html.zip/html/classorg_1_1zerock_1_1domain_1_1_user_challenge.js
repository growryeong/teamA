var classorg_1_1zerock_1_1domain_1_1_user_challenge =
[
    [ "challengeId", "classorg_1_1zerock_1_1domain_1_1_user_challenge.html#a6b3aa3e0cdc616f494662f6e83a28ba3", null ],
    [ "duration", "classorg_1_1zerock_1_1domain_1_1_user_challenge.html#ad3742dfb74bb27e97c62be0f7076720c", null ],
    [ "endDate", "classorg_1_1zerock_1_1domain_1_1_user_challenge.html#a941caa09da7e2d6c7d617d72c60046ef", null ],
    [ "progress", "classorg_1_1zerock_1_1domain_1_1_user_challenge.html#ab5e617a3db0850fc8393237f8b6d0163", null ],
    [ "startDate", "classorg_1_1zerock_1_1domain_1_1_user_challenge.html#a4225172f85d55b7242c1a5fb3e25c612", null ],
    [ "status", "classorg_1_1zerock_1_1domain_1_1_user_challenge.html#a5759692e6938d59ac658d82a56fcc4c5", null ],
    [ "taskId", "classorg_1_1zerock_1_1domain_1_1_user_challenge.html#a1b48ea073dd2696901115fad84ba96b3", null ],
    [ "userChallengeId", "classorg_1_1zerock_1_1domain_1_1_user_challenge.html#abe23185e1208ad75dd55da9278ff5423", null ],
    [ "userId", "classorg_1_1zerock_1_1domain_1_1_user_challenge.html#ab9704f2b2a173113d5edeb2626188375", null ]
];