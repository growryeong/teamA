var classorg_1_1zerock_1_1domain_1_1_user_challenge_d_t_o =
[
    [ "challengeId", "classorg_1_1zerock_1_1domain_1_1_user_challenge_d_t_o.html#a4ecdc58cb54945b868e4c08881aa4764", null ],
    [ "endDate", "classorg_1_1zerock_1_1domain_1_1_user_challenge_d_t_o.html#a02cf4d3b8fa2601e46ed4f5f2ccef722", null ],
    [ "progress", "classorg_1_1zerock_1_1domain_1_1_user_challenge_d_t_o.html#a1c2a9ad253742b2dad6fac5b610f10de", null ],
    [ "startDate", "classorg_1_1zerock_1_1domain_1_1_user_challenge_d_t_o.html#a57067a9a56190b769c6faf5bee3c37c1", null ],
    [ "status", "classorg_1_1zerock_1_1domain_1_1_user_challenge_d_t_o.html#ac9505e0cd47d43e43694a64591487c8e", null ],
    [ "userId", "classorg_1_1zerock_1_1domain_1_1_user_challenge_d_t_o.html#abea3904495aa65da9508c7af31e3b0b0", null ]
];