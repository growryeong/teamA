var _challenge_service_8java =
[
    [ "org.zerock.service.ChallengeService", "classorg_1_1zerock_1_1service_1_1_challenge_service.html", "classorg_1_1zerock_1_1service_1_1_challenge_service" ]
];