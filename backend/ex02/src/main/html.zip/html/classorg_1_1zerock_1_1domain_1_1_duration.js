var classorg_1_1zerock_1_1domain_1_1_duration =
[
    [ "durationId", "classorg_1_1zerock_1_1domain_1_1_duration.html#a11395d18f01766a158e701b25a0d7a01", null ],
    [ "value", "classorg_1_1zerock_1_1domain_1_1_duration.html#ad29fe44eeb701c8694563def196fd386", null ]
];