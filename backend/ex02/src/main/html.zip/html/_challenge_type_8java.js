var _challenge_type_8java =
[
    [ "org.zerock.domain.ChallengeType", "classorg_1_1zerock_1_1domain_1_1_challenge_type.html", "classorg_1_1zerock_1_1domain_1_1_challenge_type" ]
];