var classorg_1_1zerock_1_1controller_1_1_community_controller_1_1_community_post_request =
[
    [ "content", "classorg_1_1zerock_1_1controller_1_1_community_controller_1_1_community_post_request.html#af232041e1f1776dad7b41fd064606a01", null ],
    [ "title", "classorg_1_1zerock_1_1controller_1_1_community_controller_1_1_community_post_request.html#a125ea5ebfd35296f3d9674c04f23674a", null ],
    [ "userChallengeId", "classorg_1_1zerock_1_1controller_1_1_community_controller_1_1_community_post_request.html#a3bf1187286c87d3867f9410c51e698fd", null ],
    [ "userId", "classorg_1_1zerock_1_1controller_1_1_community_controller_1_1_community_post_request.html#ad599a68c0c0e66155edba23df7aeb29e", null ],
    [ "viewCount", "classorg_1_1zerock_1_1controller_1_1_community_controller_1_1_community_post_request.html#ae70b15ac0e918b9c07ef8e84b314f681", null ]
];