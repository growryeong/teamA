var _challenge_mapper_8java =
[
    [ "org.zerock.mapper.ChallengeMapper", "interfaceorg_1_1zerock_1_1mapper_1_1_challenge_mapper.html", "interfaceorg_1_1zerock_1_1mapper_1_1_challenge_mapper" ]
];