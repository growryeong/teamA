var classorg_1_1zerock_1_1controller_1_1_challenge_controller =
[
    [ "createChallenge", "classorg_1_1zerock_1_1controller_1_1_challenge_controller.html#a8cb338fd76578ce1ccc8db3b8cd91769", null ],
    [ "getAllChallenges", "classorg_1_1zerock_1_1controller_1_1_challenge_controller.html#a468656d0de4f6a8424cce8507d675795", null ],
    [ "getAllTasks", "classorg_1_1zerock_1_1controller_1_1_challenge_controller.html#a5ac5bf9c18b3638a6e68569f7c4143e1", null ],
    [ "getDurations", "classorg_1_1zerock_1_1controller_1_1_challenge_controller.html#a563e2e1a777ea45e391ba85a621ea39b", null ],
    [ "getTasks", "classorg_1_1zerock_1_1controller_1_1_challenge_controller.html#afec8ac834302c30d56e023a6f1093ec0", null ],
    [ "challengeService", "classorg_1_1zerock_1_1controller_1_1_challenge_controller.html#ab333076490c926e2e9e448d31704646d", null ],
    [ "durationService", "classorg_1_1zerock_1_1controller_1_1_challenge_controller.html#a778c69eba03a3f7502db7aa70f00d59b", null ]
];