var _user_challenge_8java =
[
    [ "org.zerock.domain.UserChallenge", "classorg_1_1zerock_1_1domain_1_1_user_challenge.html", "classorg_1_1zerock_1_1domain_1_1_user_challenge" ]
];