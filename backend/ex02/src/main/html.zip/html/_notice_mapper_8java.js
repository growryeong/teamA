var _notice_mapper_8java =
[
    [ "org.zerock.mapper.NoticeMapper", "interfaceorg_1_1zerock_1_1mapper_1_1_notice_mapper.html", "interfaceorg_1_1zerock_1_1mapper_1_1_notice_mapper" ]
];