var _duration_mapper_8java =
[
    [ "org.zerock.mapper.DurationMapper", "interfaceorg_1_1zerock_1_1mapper_1_1_duration_mapper.html", "interfaceorg_1_1zerock_1_1mapper_1_1_duration_mapper" ]
];