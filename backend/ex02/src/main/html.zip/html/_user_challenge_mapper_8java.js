var _user_challenge_mapper_8java =
[
    [ "org.zerock.mapper.UserChallengeMapper", "interfaceorg_1_1zerock_1_1mapper_1_1_user_challenge_mapper.html", "interfaceorg_1_1zerock_1_1mapper_1_1_user_challenge_mapper" ]
];