var classorg_1_1zerock_1_1domain_1_1_user =
[
    [ "createdAt", "classorg_1_1zerock_1_1domain_1_1_user.html#a7b83d7dc53edf7cd30f68a9d9670ca48", null ],
    [ "email", "classorg_1_1zerock_1_1domain_1_1_user.html#a22a95714716d613d48f02ef57e11d0b1", null ],
    [ "isAdmin", "classorg_1_1zerock_1_1domain_1_1_user.html#ab7fd098bdebbf339305f20c2add8e556", null ],
    [ "password", "classorg_1_1zerock_1_1domain_1_1_user.html#a67a8e8523f750bd082436e3ebe56c1a2", null ],
    [ "userId", "classorg_1_1zerock_1_1domain_1_1_user.html#adbb90ab182e072b06cea1203b525ad72", null ],
    [ "username", "classorg_1_1zerock_1_1domain_1_1_user.html#a7ab91bbc014a245d24daee046c8344a5", null ]
];