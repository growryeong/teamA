var classorg_1_1zerock_1_1controller_1_1_user_challenge_controller =
[
    [ "getOngoingChallenge", "classorg_1_1zerock_1_1controller_1_1_user_challenge_controller.html#ad7ce098c3fa2074870a9ec506d413523", null ],
    [ "getUserChallengeDetails", "classorg_1_1zerock_1_1controller_1_1_user_challenge_controller.html#afe03aa6d65ef99b57db913eef4376ed2", null ],
    [ "joinChallenge", "classorg_1_1zerock_1_1controller_1_1_user_challenge_controller.html#a348788057d8297cbc2136abb36a1e791", null ],
    [ "saveUserChallenge", "classorg_1_1zerock_1_1controller_1_1_user_challenge_controller.html#a92873b0e26b4b4c63c9503febfebd1ad", null ],
    [ "userChallengeService", "classorg_1_1zerock_1_1controller_1_1_user_challenge_controller.html#a61857cc2333f96aeaf40ca9b752df199", null ]
];