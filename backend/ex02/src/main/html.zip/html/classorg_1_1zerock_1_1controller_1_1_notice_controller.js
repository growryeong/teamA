var classorg_1_1zerock_1_1controller_1_1_notice_controller =
[
    [ "getNoticeDetail", "classorg_1_1zerock_1_1controller_1_1_notice_controller.html#a686224904ff0dd018a3adcbe514b0450", null ],
    [ "getNoticeList", "classorg_1_1zerock_1_1controller_1_1_notice_controller.html#ae0fbe76502ebff1275be8e77b21dda2d", null ],
    [ "logger", "classorg_1_1zerock_1_1controller_1_1_notice_controller.html#a7165aada5e7317bb5bc49364392c229b", null ],
    [ "noticeService", "classorg_1_1zerock_1_1controller_1_1_notice_controller.html#aaf273606a42f006250479ca2e429c0ff", null ]
];