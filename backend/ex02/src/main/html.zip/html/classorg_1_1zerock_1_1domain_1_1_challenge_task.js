var classorg_1_1zerock_1_1domain_1_1_challenge_task =
[
    [ "challengeId", "classorg_1_1zerock_1_1domain_1_1_challenge_task.html#a234b136ab67d325827081cb34fed8a63", null ],
    [ "task", "classorg_1_1zerock_1_1domain_1_1_challenge_task.html#a82bc7118a24e14e52c7931cafdb668d5", null ],
    [ "taskId", "classorg_1_1zerock_1_1domain_1_1_challenge_task.html#a2da0cd87169c2dd6ff0f71f04c4015ab", null ]
];