var namespaces_dup =
[
    [ "org", null, [
      [ "zerock", null, [
        [ "config", "namespaceorg_1_1zerock_1_1config.html", "namespaceorg_1_1zerock_1_1config" ],
        [ "controller", "namespaceorg_1_1zerock_1_1controller.html", "namespaceorg_1_1zerock_1_1controller" ],
        [ "domain", "namespaceorg_1_1zerock_1_1domain.html", "namespaceorg_1_1zerock_1_1domain" ],
        [ "mapper", "namespaceorg_1_1zerock_1_1mapper.html", "namespaceorg_1_1zerock_1_1mapper" ],
        [ "service", "namespaceorg_1_1zerock_1_1service.html", "namespaceorg_1_1zerock_1_1service" ]
      ] ]
    ] ]
];