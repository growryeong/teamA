var classorg_1_1zerock_1_1domain_1_1_login_d_t_o =
[
    [ "password", "classorg_1_1zerock_1_1domain_1_1_login_d_t_o.html#a76041caaea3c8cb1d54a391056bffb81", null ],
    [ "userId", "classorg_1_1zerock_1_1domain_1_1_login_d_t_o.html#a0849fa4bb16d2957468a63626f083daa", null ]
];