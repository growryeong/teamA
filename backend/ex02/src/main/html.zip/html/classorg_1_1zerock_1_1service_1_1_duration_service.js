var classorg_1_1zerock_1_1service_1_1_duration_service =
[
    [ "getAllDurations", "classorg_1_1zerock_1_1service_1_1_duration_service.html#acdaed9b6827ca93284c070fcab958883", null ],
    [ "durationMapper", "classorg_1_1zerock_1_1service_1_1_duration_service.html#a2bd92706d1662f4176246328493bf9ce", null ]
];