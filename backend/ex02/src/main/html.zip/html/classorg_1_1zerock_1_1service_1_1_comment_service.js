var classorg_1_1zerock_1_1service_1_1_comment_service =
[
    [ "addComment", "classorg_1_1zerock_1_1service_1_1_comment_service.html#a1e49a7e511c54b882ea4ce429f7d5df8", null ],
    [ "getCommentsByPostId", "classorg_1_1zerock_1_1service_1_1_comment_service.html#a9fdfe0091ff30420f56f6f38ef687dcf", null ],
    [ "commentMapper", "classorg_1_1zerock_1_1service_1_1_comment_service.html#a676f104b8f9c40679866b86225585090", null ]
];