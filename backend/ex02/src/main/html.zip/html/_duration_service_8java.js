var _duration_service_8java =
[
    [ "org.zerock.service.DurationService", "classorg_1_1zerock_1_1service_1_1_duration_service.html", "classorg_1_1zerock_1_1service_1_1_duration_service" ]
];