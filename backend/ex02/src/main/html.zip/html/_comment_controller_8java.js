var _comment_controller_8java =
[
    [ "org.zerock.controller.CommentController", "classorg_1_1zerock_1_1controller_1_1_comment_controller.html", "classorg_1_1zerock_1_1controller_1_1_comment_controller" ]
];