var _user_mapper_8java =
[
    [ "org.zerock.mapper.UserMapper", "interfaceorg_1_1zerock_1_1mapper_1_1_user_mapper.html", "interfaceorg_1_1zerock_1_1mapper_1_1_user_mapper" ]
];