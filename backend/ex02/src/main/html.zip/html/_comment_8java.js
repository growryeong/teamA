var _comment_8java =
[
    [ "org.zerock.domain.Comment", "classorg_1_1zerock_1_1domain_1_1_comment.html", "classorg_1_1zerock_1_1domain_1_1_comment" ]
];