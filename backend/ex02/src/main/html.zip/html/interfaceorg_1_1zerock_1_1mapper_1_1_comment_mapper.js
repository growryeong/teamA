var interfaceorg_1_1zerock_1_1mapper_1_1_comment_mapper =
[
    [ "getCommentsByPostId", "interfaceorg_1_1zerock_1_1mapper_1_1_comment_mapper.html#a7380f7bf3d2edc0a069dfb713e32f218", null ],
    [ "insertComment", "interfaceorg_1_1zerock_1_1mapper_1_1_comment_mapper.html#a453f78113f6ae78495e78522ad41c3e1", null ]
];