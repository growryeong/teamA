var _challenge_type_mapper_8java =
[
    [ "org.zerock.mapper.ChallengeTypeMapper", "interfaceorg_1_1zerock_1_1mapper_1_1_challenge_type_mapper.html", "interfaceorg_1_1zerock_1_1mapper_1_1_challenge_type_mapper" ]
];