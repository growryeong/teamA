var classorg_1_1zerock_1_1controller_1_1_comment_controller =
[
    [ "addComment", "classorg_1_1zerock_1_1controller_1_1_comment_controller.html#ac224e24d59843057406207438377b3f9", null ],
    [ "getComments", "classorg_1_1zerock_1_1controller_1_1_comment_controller.html#a33b301b89fd6d261a4a77e8980fbf403", null ],
    [ "commentService", "classorg_1_1zerock_1_1controller_1_1_comment_controller.html#af1e69be0f677f30d11f8803a7929c0f4", null ]
];